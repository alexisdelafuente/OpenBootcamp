package com.example.ejercicio_3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
